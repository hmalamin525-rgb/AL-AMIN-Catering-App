package com.alamin.catering.util

import com.alamin.catering.data.PersonDao
import com.alamin.catering.models.Person

object SeedUtil {
    suspend fun seedAllBlocks(dao: PersonDao) {
        val existing = dao.getByBlock(1)
        if (existing.isNotEmpty()) return

        val persons = mutableListOf<Person>()
        for (b in 1..40) {
            for (i in 1..10) {
                val name = "Person_${b}_$i"
                val phone = "+8801700" + String.format("%04d", b*10 + i)
                val due = when (i % 4) {
                    0 -> 1
                    1 -> 10
                    2 -> 20
                    else -> 30
                }
                persons.add(Person(blockNumber = b, name = name, phone = phone, dueDay = due, foodStart = null, paidForMonth = null, photoUri = null))
            }
        }
        dao.insert(*persons.toTypedArray())
    }
}
