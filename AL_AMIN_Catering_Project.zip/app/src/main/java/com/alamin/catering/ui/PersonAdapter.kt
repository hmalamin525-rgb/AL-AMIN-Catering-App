package com.alamin.catering.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.alamin.catering.R
import com.alamin.catering.models.Person

class PersonAdapter(private val list: MutableList<Person>) : RecyclerView.Adapter<PersonAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.imgPhoto)
        val name: TextView = v.findViewById(R.id.tvName)
        val phone: TextView = v.findViewById(R.id.tvPhone)
        val due: TextView = v.findViewById(R.id.tvDue)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_person, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = list[position]
        holder.name.text = p.name
        holder.phone.text = p.phone ?: ""
        holder.due.text = p.dueDay.toString()
    }

    override fun getItemCount(): Int = list.size
}
