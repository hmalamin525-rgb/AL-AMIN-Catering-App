package com.alamin.catering.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "person")
data class Person(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val blockNumber: Int,
    val name: String,
    val phone: String?,
    val dueDay: Int,
    val foodStart: String?,
    val paidForMonth: String?,
    val photoUri: String?
)
