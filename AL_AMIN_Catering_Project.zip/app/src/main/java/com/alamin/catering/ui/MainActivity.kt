package com.alamin.catering.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.alamin.catering.data.AppDatabase
import com.alamin.catering.util.SeedUtil
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = AppDatabase.getDatabase(this)
        val dao = db.personDao()

        lifecycleScope.launch {
            SeedUtil.seedAllBlocks(dao)
        }

        val blocksContainer = findViewById<LinearLayout>(R.id.blocksContainer)
        for (i in 1..40) {
            val btn = Button(this)
            btn.text = "Block $i"
            btn.setOnClickListener {
                val intent = Intent(this, BlockActivity::class.java)
                intent.putExtra("block", i)
                startActivity(intent)
            }
            blocksContainer.addView(btn)
        }

        findViewById<Button>(R.id.btnDueToday).setOnClickListener {
            val intent = Intent(this, BlockActivity::class.java)
            intent.putExtra("showDueToday", true)
            startActivity(intent)
        }
    }
}
