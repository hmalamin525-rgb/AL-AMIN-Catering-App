package com.alamin.catering.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.alamin.catering.models.Person

@Dao
interface PersonDao {
    @Query("SELECT * FROM person WHERE blockNumber = :block ORDER BY name")
    suspend fun getByBlock(block: Int): List<Person>

    @Query("SELECT * FROM person WHERE dueDay = :day")
    suspend fun getByDueDay(day: Int): List<Person>

    @Insert
    suspend fun insert(vararg persons: Person)

    @Update
    suspend fun update(person: Person)

    @Query("DELETE FROM person")
    suspend fun clearAll()
}
