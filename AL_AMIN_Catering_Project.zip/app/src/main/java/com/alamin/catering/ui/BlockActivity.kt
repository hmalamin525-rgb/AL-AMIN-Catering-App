package com.alamin.catering.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.alamin.catering.data.AppDatabase
import com.alamin.catering.models.Person
import kotlinx.coroutines.launch

class BlockActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block)

        val rv = findViewById<RecyclerView>(R.id.rvPeople)
        rv.layoutManager = LinearLayoutManager(this)

        val db = AppDatabase.getDatabase(this)
        val dao = db.personDao()

        val block = intent.getIntExtra("block", -1)
        val showDue = intent.getBooleanExtra("showDueToday", false)

        lifecycleScope.launch {
            val list: List<Person> = if (showDue) {
                val day = java.time.LocalDate.now().dayOfMonth
                dao.getByDueDay(day)
            } else {
                dao.getByBlock(block)
            }
            rv.adapter = PersonAdapter(list.toMutableList())
        }
    }
}
