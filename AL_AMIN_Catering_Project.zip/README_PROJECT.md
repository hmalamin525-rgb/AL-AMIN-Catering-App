AL-AMIN Catering Management - Android Studio Project

This is an importable Android Studio project (Kotlin) for the AL-AMIN Catering Management app.

How to open:
1. Transfer this ZIP to a computer with Android Studio OR upload to an online builder.
2. Open the folder in Android Studio: File -> Open -> select the folder.
3. Android Studio will sync Gradle and download necessary components.
4. Run the app on a connected device or emulator.

If you don't have a computer, I can create a GitHub repo + Actions workflow so you can build APK in the cloud.
